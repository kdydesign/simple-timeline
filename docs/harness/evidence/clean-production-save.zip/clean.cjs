const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const { createRequire } = require('node:module')
const { DatabaseSync } = require('node:sqlite')
const { createHash } = require('node:crypto')
const pause = ms => new Promise(resolve=>setTimeout(resolve,ms))
function dbCheck(filename) {
  const db=new DatabaseSync(filename,{readOnly:true})
  try { return db.prepare('SELECT count(*) AS rows, (SELECT name FROM schedules WHERE id=3) AS name FROM schedules').get() }
  finally { db.close() }
}
async function seed(repo,dest) {
  const dep=createRequire(path.join(repo,'package.json'))
  const profile=await fs.mkdtemp(path.join(os.tmpdir(),'simple-timeline-clean-seed-'))
  let app
  try {
    app=await dep('playwright')._electron.launch({chromiumSandbox:true,executablePath:dep('electron'),args:[path.join(repo,'artifacts/test-app/main/index.cjs')],env:{...process.env,SIMPLE_TIMELINE_TEST_PROFILE:profile,SIMPLE_TIMELINE_TEST_SEED:'scale'}})
    const page=await app.firstWindow()
    await page.waitForFunction(()=>document.documentElement.dataset.timelinePhase==='ready')
    await app.close()
    app=null
    const file=path.join(profile,'data/timeline.sqlite3')
    const check=dbCheck(file)
    if(check.rows!==10000||check.name!=='대량 일정 1')throw Error('Incomplete test seed')
    await fs.copyFile(file,dest)
  } finally { try{await app?.close()}finally{await fs.rm(profile,{recursive:true,force:true})} }
}
async function trial(repo,dbFile,withWindow){
  const dep=createRequire(path.join(repo,'package.json'))
  const home=await fs.mkdtemp(path.join(os.tmpdir(),'simple-timeline-prod-save-'))
  const config=path.join(home,'config'),profile=path.join(config,'SimpleTimeline')
  const data=path.join(profile,'data'),database=path.join(data,'timeline.sqlite3')
  await fs.mkdir(data,{recursive:true})
  await fs.copyFile(dbFile,database)
  let app
  try{
    // Launch package.json's production out/main entry. XDG_CONFIG_HOME keeps
    // production appData and every database, key, cache and lock in the fixture.
    app=await dep('playwright')._electron.launch({chromiumSandbox:true,executablePath:dep('electron'),args:[repo],env:{...process.env,XDG_CONFIG_HOME:config,XDG_CACHE_HOME:path.join(home,'cache'),XDG_DATA_HOME:path.join(home,'data'),LOCALAPPDATA:path.join(home,'local'),NODE_ENV:'production'}})
    const page=await app.firstWindow()
    page.setDefaultTimeout(10000)
    const runtime=await app.evaluate(({app})=>({entry:app.getAppPath(),profile:app.getPath('userData'),versions:{electron:process.versions.electron,node:process.versions.node}}))
    if(runtime.profile!==profile||runtime.entry!==repo)throw Error('Profile or package root mismatch: '+JSON.stringify(runtime))
    await page.waitForFunction(()=>document.documentElement.dataset.timelinePhase==='ready')
    const nav=page.getByRole('navigation',{name:'WorkRail 도구'})
    await nav.getByRole('button',{name:'PlanRail',exact:true}).click()
    const name='단건 저장 확인'
    await page.getByRole('button',{name:'대량 일정 1 편집',exact:true}).click()
    await page.getByLabel('일정 이름',{exact:true}).fill(name)
    await page.getByRole('button',{name:'저장',exact:true}).click()
    const confirm=page.getByRole('alertdialog').getByRole('button',{name:'변경',exact:true})
    const box=await confirm.boundingBox()
    if(!box)throw Error('Save confirmation missing')
    await pause(1600)
    const idle=withWindow?await page.evaluate(async()=>{
      const t=performance.now(),reply=await window.timelineWindow.command('toggle-maximize')
      const ms=performance.now()-t
      await window.timelineWindow.command('toggle-maximize')
      return {ms,ok:reply.ok,maximized:reply.maximized}
    }):null
    const point={x:box.x+box.width/2,y:box.y+box.height/2}
    await page.mouse.move(point.x,point.y)
    await page.evaluate(({name,withWindow})=>{
      const now=()=>performance.timeOrigin+performance.now()
      const root=document.documentElement
      const result={click:0,confirmed:0,dom:0,frames:0,window:null}
      window.wrCleanResult=result
      document.addEventListener('click',event=>{
        if(!event.isTrusted||!event.target.closest('[role="alertdialog"]'))return
        result.click=now()
      },{capture:true,once:true})
      const observer=new MutationObserver(()=>{
        if(!result.click)return
        if(!result.confirmed&&document.querySelector('.saving-shield.is-complete')){
          result.confirmed=now()
          if(withWindow)setTimeout(()=>{
            const sent=now(),phase=root.dataset.timelinePhase
            const renamedAlreadyVisible=!!document.querySelector('button[aria-label="'+name+' 편집"]')
            window.timelineWindow.command('toggle-maximize').then(reply=>{
              result.window={sent,end:now(),phase,renamedAlreadyVisible,ok:reply.ok,maximized:reply.maximized}
            })
          },6)
        }
        if(!result.dom&&root.dataset.timelinePhase==='ready'&&document.querySelector('button[aria-label="'+name+' 편집"]')&&!document.querySelector('[role="alertdialog"]')){
          result.dom=now()
          requestAnimationFrame(()=>requestAnimationFrame(()=>{result.frames=now()}))
          observer.disconnect()
        }
      })
      observer.observe(root,{subtree:true,childList:true,attributes:true,attributeFilter:['class','data-timeline-phase','aria-label']})
    },{name,withWindow})
    await app.evaluate(()=>{
      const point=()=>({t:performance.timeOrigin+performance.now(),cpu:process.threadCpuUsage()})
      const ticks=[point()]
      const timer=setInterval(()=>ticks.push(point()),5)
      globalThis.wrEndClean=()=>{clearInterval(timer);return ticks}
    })
    // Idle reference interval uses the same active timer. Between mouseup and
    // final observation there is no CDP polling, SQL, JS injection, or logging.
    await pause(350)
    await page.mouse.down()
    await page.mouse.up()
    await pause(1000)
    const ticks=await app.evaluate(()=>globalThis.wrEndClean())
    const ui=await page.evaluate(()=>window.wrCleanResult)
    if(!ui.click||!ui.confirmed||!ui.dom||!ui.frames||ui.dom<ui.click||ui.frames<ui.dom||withWindow&&!ui.window?.ok)throw Error('Missing measured boundary: '+JSON.stringify(ui))
    const stored=dbCheck(database)
    if(stored.name!==name||stored.rows!==10000)throw Error('Stored row mismatch')
    return {ui,ticks,idle,stored,entrySha256:createHash('sha256').update(await fs.readFile(path.join(repo,'out/main/index.cjs'))).digest('hex'),versions:runtime.versions}
  }finally{
    try{if(app){const closed=app.waitForEvent('close',{timeout:6000});await app.evaluate(({app})=>{setTimeout(()=>app.exit(0),5)});await closed}}
    finally{await fs.rm(home,{recursive:true,force:true})}
  }
}
async function main(){
  const [op,...args]=process.argv.slice(2)
  if(op==='seed'){await seed(path.resolve(args[0]),path.resolve(args[1]));return}
  const [repo,seedFile,mode,dest]=args
  const result=await trial(path.resolve(repo),path.resolve(seedFile),mode==='window')
  await fs.writeFile(dest,JSON.stringify(result))
  console.log(dest)
}
main().catch(error=>{console.error(error);process.exitCode=1})
