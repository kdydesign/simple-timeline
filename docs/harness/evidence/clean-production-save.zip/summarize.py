import json,statistics,sys
from pathlib import Path
root=Path(sys.argv[1])
groups={}
for f in sorted(root.glob('*.json')):
    key,mode,num=f.stem.rsplit('-',2)
    r=json.loads(f.read_text())
    ui=r['ui']
    start,end=ui['click'],ui['frames']
    ticks=r['ticks']
    gaps=[(a['t'],b['t'],(b['cpu']['user']+b['cpu']['system']-a['cpu']['user']-a['cpu']['system'])/1000) for a,b in zip(ticks,ticks[1:])]
    def intersecting(left,right):
        return [g for g in gaps if g[1]>=left and g[0]<=right]
    def longest(group):
        return max(group,key=lambda g:g[1]-g[0])
    initial=longest(intersecting(start-275,start-30))
    a,b,cpu=longest(intersecting(start,end))
    occupied=max(0,min(b,end)-max(a,start))
    contained=[v-u for u,v,_ in gaps if u>=start and v<=end]
    sample={'confirmToConfirmed':ui['confirmed']-start,'confirmToDom':ui['dom']-start,'confirmToTwoFrames':end-start,'longestGap':b-a,'longestGapOverlap':occupied,'longestGapMainThreadCpu':cpu,'longestGapCpuFraction':100*cpu/(b-a),'maxGapEntirelyWithinUi':max(contained or [0]),'idleLongestGap':initial[1]-initial[0]}
    if mode=='window':
        w=ui['window']
        sample.update({'idleWindow':r['idle']['ms'],'refreshWindow':w['end']-w['sent'],'windowAtSavingPhase':int(w['phase']=='saving' and not w['renamedAlreadyVisible']),'windowSentAfterConfirm':w['sent']-start})
    target=groups.setdefault(key+'/'+mode,{})
    for k,v in sample.items():target.setdefault(k,[]).append(v)
print(json.dumps({g:{k:{'n':len(v),'median':round(statistics.median(v),2),'range':[round(min(v),2),round(max(v),2)],'runs':[round(x,2) for x in v]} for k,v in metrics.items()} for g,metrics in groups.items()},indent=2))
