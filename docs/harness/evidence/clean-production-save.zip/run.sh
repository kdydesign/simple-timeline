#!/usr/bin/env bash
set -eu
command=$1
before=$2
after=$3
candidate=$4
results=$5
script_dir=$(cd "$(dirname "$0")" && pwd)
if [[ "$command" == build ]]; then
  for src in "$before" "$after" "$candidate"; do
    (cd "$src" && node_modules/.bin/electron-vite build --config electron.vite.config.mts)
  done
  exit
fi
mkdir -p "$results/raw"
seed="$results/seed.sqlite3"
if [[ ! -f "$seed" ]]; then node "$script_dir/clean.cjs" seed "$before" "$seed"; fi
for i in 1 2 3 4 5; do
  case $((i%3)) in
    1) variants=(before after bypass);;
    2) variants=(bypass before after);;
    0) variants=(after bypass before);;
  esac
  for variant in "${variants[@]}"; do
    case $variant in before) build=$before;; after) build=$after;; bypass) build=$candidate;; esac
    for mode in save window; do
      node "$script_dir/clean.cjs" trial "$build" "$seed" "$mode" "$results/raw/$variant-$mode-$i.json"
    done
  done
done
python3 "$script_dir/summarize.py" "$results/raw" > "$results/summary.json"
