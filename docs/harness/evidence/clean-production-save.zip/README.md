# 단건 저장 재현 — 제품 Vite 빌드

이 실험은 직접 함수 계측을 제거한 Linux 제품 실행 경로에서 1만 일정 저장 중 타이머 간격과 창 명령 응답을 확인한다. 설치된 npm Electron에서 실제 package.json을 시작해 out/main, out/preload, out/renderer를 로드한다. Windows 설치본은 별도 대상이다.

각 프로세스는 임시 XDG 디렉터리의 동일한 SQLite 복사본을 사용한다. E2E 진입점은 한 번만 사용해 저장소의 1만 건 fixture 원본을 만든다. 저장 측정에는 테스트 진입점, 테스트용 afterDispatch, 번들 수정, 함수 계측, CPU 프로파일러를 사용하지 않는다. 저장 확인과 ‘대량 일정 1’의 실제 변경은 신뢰된 마우스 입력과 읽기 전용 DB로 확인한다.

* save는 DOM에서 저장 확인 클릭, 저장 완료 표시, 변경된 간트 이름과 준비 상태, 그 뒤 두 프레임을 관찰한다. 창 명령은 보내지 않는다.
* window에서는 별도 프로필에 같은 동작을 반복한다. 저장 완료 표시를 DOM에서 관찰한 뒤 6ms 타이머로 최대화 전환을 한 번 보낸다. 실제 요청 시점 및 그때의 저장 상태를 원시값에 남긴다. Xvfb에서는 OS 창 크기 변화보다 명령의 전송-응답 시간에 의미가 있다. 이 시작점은 앞선 계측 실험에서 getSnapshot 호출 직후 보낸 경우와 다르다.
* 두 모드에서 5ms 메인 타이머의 실제 콜백 시각과 누적 메인 스레드 user+system CPU를 수집한다. 전체 앱 프로세스 CPU·다른 GC 스레드 작업·모니터 배치는 별도다. 긴 구간 그 자체와, UI 구간과 겹친 시간, 전체가 UI에 포함된 구간을 구분한다. 측정하는 1초 동안 마우스 입력 뒤 Playwright polling·추가 CDP 호출은 없다.
* before는 3271e63이다. after는 save-release-benchmark.zip 안에 든 measured-source.patch를 같은 커밋에 적용한 빌드다. bypass는 after에 ipc-cold-read.patch를 추가한 실험용 빌드다. IPC로 나가는 신규 리비전의 DTO 복사만 건너뛴다. 직접 repository를 호출할 때는 호출자 분리 정책을 유지한다.
* 세 빌드 실행 순서를 순환한다. 각 조건마다 새 앱 5회, 총 30개 측정 프로세스다. 실행별 원시시각과 CPU 값은 raw/, 중앙값·최소·최대는 summary.json이다.

세 개의 별도 소스 디렉터리에서 npm ci를 실행한다. 먼저 before에서 npm run build:test를 수행해 fixture 생성 진입점을 준비한다. 다음 명령은 제품 빌드와 전체 측정을 실행한다.

```bash
./run.sh build /path/to/before /path/to/after /path/to/bypass "$PWD/results"
DISPLAY=:176 CHROME_DEVEL_SANDBOX=/usr/lib/chromium/chrome-sandbox \
  ./run.sh measure /path/to/before /path/to/after /path/to/bypass "$PWD/results"
```

## 판독

일반 저장의 가장 긴 메인 타이머 간격은 기존 49.1ms, 변경 33.6ms(29.4–65.2ms), 추가 실험 40.6ms였다. 그 간격 동안 메인 스레드의 CPU 사용 중앙값은 각각 41.3, 32.2, 34.6ms였다. 앞선 계측 번들에서 변경 후 130ms 이상이었던 현상은 이 제품 빌드 측정 5회에서 재현되지 않았다. 마커, 실행 진입점, 프로필 준비 방법, Playwright 관찰 방식이 함께 달라져 원인을 하나로 확정할 수 없다.

저장 확인부터 두 프레임까지는 165.8 → 151.9ms였다. 별도 창 명령은 60.4 → 68.3ms(실행별 52.2–86.0 → 51.3–113.0ms)로 재조회 중에도 지연이 남았다. IPC에서 첫 읽기의 방어 복사를 생략한 실험은 두 프레임 164.5ms, 창 명령 85.6ms였다.
