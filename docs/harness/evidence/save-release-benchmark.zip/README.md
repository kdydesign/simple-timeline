# 저장·창 조작·릴리즈노트 비교 측정

기준은 3271e63, 비교 대상은 2026-11-20의 간트·달력, SQLite·공유 조회, 알림, 릴리즈노트 명시적 닫기 개선을 통합한 일회성 테스트 빌드다. 두 빌드의 해시는 manifest.json에 있다. 측정 후 추가된 닫기와 트레이 전환의 경합 처리는 이 실험의 순차 닫기·열기 범위 밖이다.

각 실행은 새 프로세스와 새 임시 프로필을 쓴다. Linux x64, Electron 45.2.1, Xvfb 1440×1000, 4 CPU 할당, 32 GiB, sandbox 활성 환경이다. 두 별도 체크아웃을 기준 SHA로 맞추고 변경 쪽에서 git apply /path/to/measured-source.patch를 실행한다. 각 체크아웃에서 npm ci 및 npm run build:test로 Linux 테스트 빌드를 만든 뒤 아래 명령을 실행한다. 스크립트는 두 빌드를 복사해 계측하며 프로젝트의 소스와 출력에는 쓰지 않는다. 각 JSON은 한 프로세스의 측정값이다.

```bash
DISPLAY=:176 CHROME_DEVEL_SANDBOX=/usr/lib/chromium/chrome-sandbox \
  ./run-pairs.sh /path/to/before /path/to/after "$PWD/results/raw" 3
DISPLAY=:176 CHROME_DEVEL_SANDBOX=/usr/lib/chromium/chrome-sandbox \
  ./extra-saves.sh /path/to/before /path/to/after "$PWD/results/raw"
```

* **save**는 1만 건의 기존 일정 중 간트의 ‘대량 일정 1’을 이름만 수정한다. 저장 버튼 뒤의 ‘변경’ 확인 클릭부터 실제 간트 이름·준비 상태를 DOM에서 확인하고 두 번의 애니메이션 프레임까지 측정한다. 각 실행에서 별도로 SQLite의 이름과 1만 건 유지를 확인한다. 계측은 번들에서 해당 호출식에 시각 기록만 감싼다. main과 renderer는 각각 performance.timeOrigin + performance.now()로 기록한다. CPU 독점 시간이나 실제 모니터 표출 시각을 뜻하지 않는다.
* 재조회는 저장 성공 뒤 renderer의 첫 getStatus와 getSnapshot이다. 공유 상태 변경으로 나중에 추가 reconcile이 발생할 수 있어 원시 이벤트 전체를 보관한다. SQL은 프로젝트·참여자·일정 .all() 행 반환 경과 시간이며 DTO 구간은 프로젝트·일정 map을 둘러싼 경과에서 .all()을 뺀 값이다. 이전 결합은 sortSnapshot의 인자를 만드는 시간이고 정렬은 sortSnapshot 전체에서 인자 시간을 뺀 값이다. 이후 결합은 readSnapshot에서 local.getSnapshot을 뺀 공유 메타데이터 조회·표시·결합 시간이다. 개인 fixture에서 별도 정렬 호출은 0회다. 방어 복사와 JSON 검사는 별도다. 중첩 시간은 합산할 수 없다. sqlite.writeTransaction은 local.updateSchedule 내부이며, 변경 후 공유 계층이 연 바깥 트랜잭션의 최종 커밋까지는 saveDispatch에 들어간다.
* **window**는 별도 프로세스에서 같은 실제 저장을 한다. idle에서 최대화 전환을 호출하고 복원한 뒤, renderer에서 전체 재조회 요청을 보낸 직후 같은 창의 최대화 전환을 보낸다. 첫 재조회와 겹친 첫 전환의 실제 IPC 응답 시간을 기록한다. 이후의 자동 재조회에서 같은 진단이 재실행될 수 있다. Xvfb에서 명령은 모두 ok, maximized는 false였다. 표의 대상은 메인이 명령을 처리해 renderer가 응답을 받은 시간이며 네이티브 창 크기 변화·표시는 별도다. 5ms 메인 타이머 간격은 별도로 보관한다.
* **repeat**는 두 빌드 모두 계측하지 않은 번들로 실행한다. 이전 2차 실험의 ipcCase를 그대로 사용한다. 1만 건에서 getSnapshot 1회 예열하고 1.8초 기다린 뒤 getStatus·getSnapshot 각 20회를 목표 120ms 간격으로 요청한다. API 순서는 실행마다 교대한다. 한 실행 내부 왕복 중앙값과 5ms 메인 타이머 간격 p95를 계산하고 실행별 값을 다시 요약한다.
* **release**도 계측하지 않은 3건 fixture다. 도움말을 열어 준비를 확인하고 닫은 뒤 릴리즈노트를 3번 열고 닫는다. 0.8.3을 선택하고 다시 열었을 때 같은 버전의 제목을 확인한다. 각 닫기 및 주 창 트레이 숨김 후 750ms에 app.getAppMetrics()의 모든 PID별 /proc/PID/smaps_rollup Pss를 더한다. 같은 실행의 각 샘플에서 도움말 PID와 숨김을 검증한다. 최초 열기 대비 재열기는 주 창의 열기 요청부터 관측자가 대상 창의 준비된 제목·가시성·두 프레임을 확인할 때까지다. 여기에 Playwright가 대상 페이지를 획득하는 시간도 포함된다.
* 기준/변경의 실행 순서는 각 쌍에서 교대로 바꾼다. median·min·max와 실행별 수치는 summary.json에 있다. PSS는 공유 페이지를 분담하며 JS 힙과 단위가 다르다. Windows 배율, 사용자 PC, 실제 LAN 동기화는 이 측정에 포함되지 않는다.
