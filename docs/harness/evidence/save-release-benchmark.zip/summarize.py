import json, statistics, sys
from pathlib import Path

def dt(event):
    return event['end']-event['start']

def span(events, name):
    matches=[e for e in events if e['label']==name]
    if len(matches)!=1:
        raise ValueError(f'Expected one {name}, got {len(matches)}')
    return matches[0]

def first(events,name):
    return min((e for e in events if e['label']==name),key=lambda e:e['start'])

def total(events,name):
    return sum(dt(e) for e in events if e['label']==name)

def children(events,bound):
    return [e for e in events if e['start']>=bound['start'] and e['end']<=bound['end']]

def save(o):
    events=o['main']['events']
    ui=o['renderer']['ui']
    renderer=o['renderer']['events']
    if not ui['confirm']<ui['dom']<ui['frames']:
        raise ValueError(ui)
    save=span(renderer,'renderer.operation')
    read=first(renderer,'renderer.api.getSnapshot')
    dispatch=first(events,'ipc.dispatch.getSnapshot')
    details=children(events,dispatch)
    sql=total(details,'sql.snapshotSchedules')+total(details,'sql.snapshotProjects')+total(details,'sql.snapshotParticipants')
    map_sql=total(details,'sql.snapshotSchedules')+total(details,'sql.snapshotProjects')
    dto=total(details,'map.snapshotSchedules')+total(details,'map.snapshotProjects')-map_sql
    sort=total(details,'sharing.sortWithArgument')-total(details,'sharing.materializeSortArgument')
    merge=total(details,'sharing.materializeSortArgument') if sort else total(details,'sharing.readSnapshot')-total(details,'sharing.localSnapshot')
    intersecting=[dt(g) for g in o['main']['gaps'] if g['end']>=ui['confirm'] and g['start']<=ui['frames']]
    primary={
        'confirmToDom':ui['dom']-ui['confirm'],
        'confirmToTwoFrames':ui['frames']-ui['confirm'],
        'saveIpc':dt(save),
        'statusIpc':dt(span(renderer,'renderer.api.getStatus')),
        'snapshotIpc':dt(read),
        'snapshotMainDispatch':dt(dispatch),'snapshotIpcOutsideDispatch':dt(read)-dt(dispatch),
        'snapshotSqlRowFetch':sql,
        'snapshotProjectScheduleDto':dto,
        'snapshotMergeOrMetadata':merge,
        'snapshotSort':sort,
        'snapshotDefensiveCopy':total(details,'sharing.copySnapshot'),
        'snapshotJsonValidation':total(details,'dispatch.JSON.stringify'),
        'readReturnToDom':ui['dom']-read['end'],
        'readReturnToTwoFrames':ui['frames']-read['end'],
        'saveDispatch':dt(span(events,'ipc.dispatch.updateSchedule')),
        'innerSqliteWrite':total(events,'sqlite.writeTransaction'),
        'dormantGuardOrLookup':total(events,'sharing.dormantGuardRead')+total(events,'sharing.sharedSchedule.get'),
        'reminderSnapshot':total(events,'reminder.snapshot'),
        'localSnapshotReadsThroughInitialRefresh':len([e for e in events if e['label']=='sql.snapshotSchedules' and e['end']<=dispatch['end']]),
        'maxMainTimerGap':max(intersecting),'mainGapsOver50ms':sum(g>50 for g in intersecting)
    }
    if o['control']:
        window=first(renderer,'window.concurrent')
        if not window['ok']:raise ValueError(window)
        primary.update({'windowIdle':o['control']['latency'],'windowWhileReloading':dt(window)})
    return primary

def release(o):
    values=[sum(p['pssKiB'] for p in rows)/1024 for rows in o['samples']]
    return {
        'helpOnlyMiB':values[0],'afterNotesCloseMiB':values[1],'thirdNotesCloseMiB':values[3],'trayMiB':values[4],
        'firstCloseGainMiB':values[1]-values[0],'thirdCloseGainMiB':values[3]-values[0],
        'helpPssMiBAtFirstClose':sum(p['pssKiB'] for p in o['samples'][1] if p['role']=='help.html')/1024,
        'notesPssMiBAtFirstClose':sum(p['pssKiB'] for p in o['samples'][1] if p['role']=='release-notes.html')/1024,
        'firstOpenTwoFrames':o['opens'][0]['latency'],'reopenTwoFrames':statistics.median(o['latency'] for o in o['opens'][1:])
    }

def repeat(o):
    out={}
    for method,observed in o.items():
        durations=observed['durations']
        gaps=sorted(observed['gaps'])
        assert len(durations)==20
        out.update({
            method+'MedianIpc':statistics.median(durations),
            method+'P95MainGap':gaps[max(0, int(len(gaps)*.95+.99999)-1)],
            method+'MaxMainGap':max(gaps),
            method+'MainGapsOver50ms':sum(g>50 for g in gaps)
        })
    return out

directory=Path(sys.argv[1])
groups={}
for path in sorted(directory.glob('*.json')):
    record=json.loads(path.read_text())
    if 'observation' not in record:continue
    key=record['variant']+'/'+record['mode']
    values=({'release':release,'repeat':repeat}.get(record['mode'],save))(record['observation'])
    group=groups.setdefault(key, {})
    for metric,value in values.items():group.setdefault(metric,[]).append(value)
summary={k:{m:{'runs':len(v),'median':round(statistics.median(v),3),'min':round(min(v),3),'max':round(max(v),3),'raw':[round(x,3) for x in v]} for m,v in metrics.items()} for k,metrics in groups.items()}
print(json.dumps(summary,ensure_ascii=False,indent=2))
