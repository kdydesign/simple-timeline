#!/usr/bin/env bash
set -eu
before=$1
after=$2
out=$3
script_dir=$(cd "$(dirname "$0")" && pwd)
for i in 4 5; do
  variants=(after before)
  if [[ $i == 5 ]]; then variants=(before after); fi
  for variant in "${variants[@]}"; do
    build=$before
    if [[ "$variant" == after ]]; then build=$after; fi
    node "$script_dir/measure.cjs" "$build" "$variant" save,window 1 "$out" "$i"
  done
done
python3 "$script_dir/summarize.py" "$out" > "$out/../summary.json"
