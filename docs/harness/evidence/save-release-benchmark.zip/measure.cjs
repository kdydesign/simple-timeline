const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const {createRequire} = require('node:module')
const {instrument} = require('./instrument.cjs')
const pause = ms => new Promise(resolve=>setTimeout(resolve,ms))
async function poll(fn) {
  const deadline=performance.now()+15000
  while(performance.now()<deadline){
    const result=await fn()
    if(result)return result
    await pause(15)
  }
  throw Error('Observation timed out')
}
async function collect(app){
  const processes=await app.evaluate(({app,BrowserWindow})=>{
    const windows=BrowserWindow.getAllWindows()
    return app.getAppMetrics().map(({pid,type})=>{
      const win=windows.find(w=>w.webContents.getOSProcessId()===pid)
      return {pid,type,role:win?win.webContents.getURL().split('/').pop():type,visible:win?.isVisible()??null}
    })
  })
  for(const p of processes){
    const smaps=await fs.readFile('/proc/'+p.pid+'/smaps_rollup','utf8')
    p.pssKiB=Number(/^Pss:\s+(\d+)/m.exec(smaps)[1])
  }
  return processes
}
async function releaseCase(app,page,profile){
  // Hold help constant in both variants. Match the previous report's explicit
  // open then close state, and verify that its OS PID survives every sample.
  const cmd=async(name,...args)=>page.evaluate(([n,...a])=>window.timelineWindow.command(n,...a),[name,...args])
  await cmd('help','home')
  const help=await poll(()=>app.windows().find(p=>p.url().endsWith('/help.html')))
  await poll(async()=>{
    const report=await fs.readFile(path.join(profile,'help-latest.json'),'utf8').then(JSON.parse).catch(()=>null)
    return report?.requests?.some(x=>x.readyMs&&x.shownMs)
  })
  await help.evaluate(()=>window.planrailHelp.command('close'))
  await pause(750)
  const samples=[await collect(app)]
  const helpPid=samples[0].find(p=>p.role==='help.html'&&!p.visible)?.pid
  if(!helpPid)throw Error('Help control missing')
  const opens=[]
  for(let cycle=0;cycle<3;cycle++){
    const wanted=cycle===0?'WorkRail 1.0.0':'Planrail 0.8.3'
    const start=await page.evaluate(()=>{
      const start=performance.timeOrigin+performance.now()
      void window.timelineWindow.command('release-notes')
      return start
    })
    const win=await poll(()=>app.windows().find(p=>!p.isClosed()&&p.url().endsWith('/release-notes.html')))
    const completed=await win.evaluate(async heading=>{
      // A reused renderer already contains its heading. Wait for visibility, and
      // require it to survive two animation frames, in both lifecycle variants.
      const deadline=performance.now()+10000
      while(document.visibilityState!=='visible'||document.querySelector('main h1')?.textContent!==heading){
        if(performance.now()>deadline)throw Error('Release content/reading position missing: '+heading)
        await new Promise(r=>setTimeout(r,8))
      }
      await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))
      return performance.timeOrigin+performance.now()
    },wanted)
    opens.push({start,completed,latency:completed-start})
    if(cycle===0){
      await win.getByRole('button',{name:'0.8.3',exact:true}).click()
      await win.getByRole('heading',{name:'Planrail 0.8.3',exact:true}).waitFor()
    }
    await win.getByRole('button',{name:'릴리즈노트 닫기'}).click()
    await poll(async()=>app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows().every(w=>!w.webContents.getURL().endsWith('/release-notes.html')||!w.isVisible())))
    await pause(750)
    samples.push(await collect(app))
  }
  await cmd('close')
  await poll(()=>app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows().every(w=>!w.isVisible())))
  await pause(750)
  samples.push(await collect(app))
  if(samples.some(rows=>!rows.some(p=>p.role==='help.html'&&!p.visible&&p.pid===helpPid)))throw Error('Help state changed')
  return {samples,opens}
}
async function ipcCase(app,page,order,n){
  const output={}
  const one=async(method,count)=>page.evaluate(async({method,count,n})=>{
    const durations=[]
    for(let i=0;i<count;i++){
      const t=performance.now();const reply=await window.simpleTimeline[method]();durations.push(performance.now()-t)
      if(!reply.ok)throw Error('IPC read failed')
      if(method==='getSnapshot'&&reply.data?.schedules?.length!==n)throw Error('fixture count mismatch '+JSON.stringify(Object.keys(reply)))
      if(count>1)await new Promise(resolve=>setTimeout(resolve,Math.max(0,120-(performance.now()-t))))
    }
    return durations
  },{method,count,n})
  await one('getSnapshot',1);await pause(1800)
  for(const method of order){
    await app.evaluate(()=>{
      const now=()=>performance.now()
      let last=now()
      const gaps=[]
      const timer=setInterval(()=>{const t=now();gaps.push(t-last);last=t},5)
      globalThis.finishProbe=()=>{clearInterval(timer);gaps.push(now()-last);return gaps}
    })
    const durations=await one(method,20)
    const gaps=await app.evaluate(()=>globalThis.finishProbe())
    output[method]={durations,gaps}
  }
  return output
}
async function saveCase(app,page,withWindow){
  const nav=page.getByRole('navigation',{name:'WorkRail 도구'})
  await nav.getByRole('button',{name:'PlanRail',exact:true}).click()
  const original='대량 일정 1'
  const renamed='실측 단건 수정'
  await page.getByRole('button',{name:original+' 편집',exact:true}).click()
  await page.getByLabel('일정 이름',{exact:true}).fill(renamed)
  await page.getByRole('button',{name:'저장',exact:true}).click()
  const confirm=page.getByRole('alertdialog').getByRole('button',{name:'변경',exact:true})
  await confirm.waitFor()
  await pause(1600)
  const control=await page.evaluate(async measure=>{
    if(!measure)return null
    const start=performance.now()
    const reply=await window.timelineWindow.command('toggle-maximize')
    const latency=performance.now()-start
    if(!reply.ok)throw Error('Window control failed')
    await window.timelineWindow.command('toggle-maximize')
    return {latency,maximized:reply.maximized}
  },withWindow)
  if(withWindow)await pause(300)
  await app.evaluate(()=>{
    globalThis.wrSaveEvents=[]
    const now=()=>performance.timeOrigin+performance.now()
    let last=now()
    const gaps=[]
    const timer=setInterval(()=>{const end=now();gaps.push({start:last,end});last=end},5)
    globalThis.wrFinish=()=>{clearInterval(timer);return {events:wrSaveEvents,gaps}}
  })
  await page.evaluate(({renamed,withWindow})=>{
    window.wrSaveEvents=[]
    window.wrWindowTrial=withWindow
    window.wrUi={}
    const now=()=>performance.timeOrigin+performance.now()
    const root=document.getElementById('root')
    const observer=new MutationObserver(()=>{
      if(document.documentElement.dataset.timelinePhase!=='ready'||
         !root.querySelector('button[aria-label="'+renamed+' 편집"]')||
         root.querySelector('[role="alertdialog"]'))return
      observer.disconnect()
      window.wrUi.dom=now()
      requestAnimationFrame(()=>requestAnimationFrame(()=>{window.wrUi.frames=now()}))
    })
    observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true})
    document.addEventListener('click',()=>{window.wrUi.confirm=now()},{capture:true,once:true})
  },{renamed,withWindow})
  await confirm.click()
  await page.waitForFunction(requireWindow=>window.wrUi.frames&&(!requireWindow||window.wrSaveEvents.some(e=>e.label==='window.concurrent')),withWindow)
  const main=await app.evaluate(()=>globalThis.wrFinish())
  const renderer=await page.evaluate(()=>({events:window.wrSaveEvents,ui:window.wrUi}))
  const stored=await app.evaluate(()=>{
    const db=globalThis.testStorage.db
    return {rows:Number(db.prepare('SELECT count(*) AS n FROM schedules').get().n),name:db.prepare('SELECT name FROM schedules WHERE id=3').get().name}
  })
  if(stored.name!==renamed||stored.rows!==10000||!renderer.events.some(e=>e.label==='renderer.operation'))throw Error('Committed single-save invariant failed')
  return {main,renderer,control,stored}
}
async function main(){
  const [repoArg,variant,modeArg='save,window,release',count='3',destArg='.',first='1']=process.argv.slice(2)
  const repo=path.resolve(repoArg),dest=path.resolve(destArg)
  const dep=createRequire(path.join(repo,'package.json'))
  const {_electron}=dep('playwright')
  const modes=modeArg.split(',')
  const build=modes.some(m=>['save','window'].includes(m))?await instrument(repo):null
  await fs.mkdir(dest,{recursive:true})
  try{
    for(let i=Number(first);i<Number(first)+Number(count);i++)for(const mode of modes){
      if(!['save','window','release','repeat'].includes(mode))throw Error('Unknown mode '+mode)
      const out=path.join(dest,[variant,mode,i].join('-')+'.json')
      const profile=await fs.mkdtemp(path.join(os.tmpdir(),'simple-timeline-phase2-save-'))
      let app
      try{
        app=await _electron.launch({
          chromiumSandbox:true,executablePath:dep('electron'),args:[['save','window'].includes(mode)?build.main:path.join(repo,'artifacts/test-app/main/index.cjs')],
          env:{...process.env,SIMPLE_TIMELINE_TEST_PROFILE:profile,SIMPLE_TIMELINE_TEST_SEED:mode==='release'?'hotfix':'scale'}
        })
        const page=await app.firstWindow()
        page.setDefaultTimeout(9000)
        await page.waitForFunction(()=>document.documentElement.dataset.timelinePhase==='ready')
        const observation=mode==='repeat'
          ? await ipcCase(app,page,i%2?['getStatus','getSnapshot']:['getSnapshot','getStatus'],10000)
          : mode==='release'?await releaseCase(app,page,profile):await saveCase(app,page,mode==='window')
        const versions=await app.evaluate(()=>({electron:process.versions.electron,node:process.versions.node,chrome:process.versions.chrome}))
        await fs.writeFile(out,JSON.stringify({variant,mode,i,versions,buildHashes:build?.buildHashes,hooks:build?.hooks,observation},null,2))
        console.log(out)
      }finally{
        try{await app?.close()}finally{await fs.rm(profile,{recursive:true,force:true})}
      }
    }
  }finally{if(build)await fs.rm(build.tmp,{recursive:true,force:true})}
}
main().catch(e=>{console.error(e);process.exitCode=1})
