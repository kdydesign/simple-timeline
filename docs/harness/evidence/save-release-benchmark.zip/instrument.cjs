const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const { createRequire } = require('node:module')
const { createHash } = require('node:crypto')

// Only edit disposable copies of the compiled test build. Parsed expression
// boundaries let nested calls retain their original argument evaluation order.
async function instrument(repo) {
  const dep = createRequire(path.join(repo, 'package.json'))
  const {parse} = dep('@babel/parser')
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'wr-save-build-'))
  const dist = path.join(tmp, 'artifacts/test-app')
  await fs.cp(path.join(repo, 'artifacts/test-app'), dist, {recursive:true})
  for (const name of ['resources','node_modules','package.json']) {
    await fs.symlink(path.resolve(repo,name),path.join(tmp,name))
  }
  const buildHashes = {}
  const hooks = {}
  async function edit(file, domain) {
    const source = await fs.readFile(file,'utf8')
    buildHashes[domain] = createHash('sha256').update(source).digest('hex')
    const tree = parse(source,{sourceType:'unambiguous'})
    const insertions = new Map()
    function insert(i,v) { insertions.set(i, (insertions.get(i) ?? '')+v) }
    function wrap(node,label,asyncMode=false,method=false) {
      hooks[label]=(hooks[label]??0)+1
      const key = JSON.stringify(label)+(method?'+"."+method':'')
      insert(node.start, (asyncMode?'wrAsync':'wrSync')+'('+key+',()=>(')
      insert(node.end,'))')
    }
    function visit(node,scope) {
      if(node.type==='FunctionDeclaration'&&node.id&&!['useTimeline','createReminderEngine'].includes(scope))scope=node.id.name
      if(node.type==='CallExpression'||node.type==='OptionalCallExpression') {
        const target=source.slice(node.callee.start,node.callee.end)
        if(domain==='main') {
          if(scope==='createReminderSnapshotReader'&&target==='candidates.all')wrap(node,'sql.reminderCandidates')
          if(scope==='createRepository') {
            if(/^snapshot(Projects|Participants|Schedules)\.all$/.test(target)) wrap(node,'sql.'+target.split('.')[0])
            if(target==='snapshotSchedules.all().map'||target==='snapshotProjects.all().map') wrap(node,'map.'+target.split('.')[0])
          }
          if(['createSharingRepository','readSnapshot','getSnapshot'].includes(scope)) {
            if(['copySnapshot','readCommitted','readSnapshot','sharedIds.all','sharedSchedule.get'].includes(target))wrap(node,'sharing.'+target)
            if(target==='local.getSnapshot')wrap(node,'sharing.localSnapshot')
            if(target==='store.dormantSnapshot')wrap(node,'sharing.dormantGuardRead')
            if(target==='local.updateSchedule')wrap(node,'sqlite.writeTransaction')
            if(target==='sortSnapshot'){
              wrap(node,'sharing.sortWithArgument')
              wrap(node.arguments[0],'sharing.materializeSortArgument')
            }
          }
          if(scope==='dispatch'&&['fn','JSON.stringify'].includes(target))wrap(node,'dispatch.'+target)
          if(scope==='registerTimelineIpc'&&target==='dispatch')wrap(node,'ipc.dispatch',false,true)
          if(scope==='bootstrap'&&['evaluateReminders','sharing?.notifyLocalMutation'].includes(target))wrap(node,'postCommit.'+target)
          if(scope==='createReminderEngine'&&target==='o.snapshot')wrap(node,'reminder.snapshot')
        } else if(scope==='useTimeline') {
          if(['operation','api.getSnapshot','api.getStatus'].includes(target)&&!node.arguments.length)wrap(node,'renderer.'+target,true)
        }
      }
      for(const value of Object.values(node)){
        if(Array.isArray(value)){for(const item of value)if(item?.type)visit(item,scope)}
        else if(value?.type)visit(value,scope)
      }
    }
    visit(tree,'')
    let output=source
    for(const [i,code] of [...insertions].sort((a,b)=>b[0]-a[0])) output=output.slice(0,i)+code+output.slice(i)
    // Clocks use epoch-based monotonic timestamps in both processes.
    const helper = [
      'function wrTime(){return performance.timeOrigin+performance.now()}',
      'function wrSync(label,call){const events=globalThis.wrSaveEvents;if(!events)return call();const start=wrTime();try{return call()}finally{events.push({label,start,end:wrTime()})}}',
      'async function wrAsync(label,call){const events=globalThis.wrSaveEvents;if(!events)return call();const start=wrTime();try{const pending=call();if(label==="renderer.api.getSnapshot"&&globalThis.wrWindowTrial){const w=wrTime();window.timelineWindow.command("toggle-maximize").then(reply=>events.push({label:"window.concurrent",start:w,end:wrTime(),ok:reply.ok,maximized:reply.maximized}));}return await pending}finally{events.push({label,start,end:wrTime()})}}',
    ].join('\n')
    await fs.writeFile(file,output+'\n'+helper+'\n')
  }
  const assets=path.join(dist,'renderer/assets')
  const appFile=(await fs.readdir(assets)).find(n=>/^main-[^.]+\.js$/.test(n))
  const main=path.join(dist,'main/index.cjs')
  await edit(main,'main')
  await edit(path.join(assets,appFile),'renderer')
  for(const label of ['renderer.operation','renderer.api.getSnapshot','sql.snapshotSchedules','map.snapshotSchedules','ipc.dispatch']) {
    if(!hooks[label])throw Error('Missing instrumentation for '+label)
  }
  return {main,tmp,buildHashes,hooks}
}
module.exports={instrument}
