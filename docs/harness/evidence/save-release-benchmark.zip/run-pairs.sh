#!/usr/bin/env bash
set -eu
before=$1
after=$2
out=$3
runs=${4:-3}
script_dir=$(cd "$(dirname "$0")" && pwd)
for ((i=1; i<=runs; i++)); do
  variants=(before after)
  if (( i % 2 == 0 )); then variants=(after before); fi
  for variant in "${variants[@]}"; do
    build=$before
    if [[ "$variant" == after ]]; then build=$after; fi
    node "$script_dir/measure.cjs" "$build" "$variant" save,window,release,repeat 1 "$out" "$i"
  done
done
python3 "$script_dir/summarize.py" "$out" > "$out/../summary.json"
