const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const repo = process.cwd()
const dep = require('node:module').createRequire(path.join(repo,'package.json'))
const { _electron } = dep('playwright')
const pause = ms => new Promise(r => setTimeout(r,ms))
const stats = []
async function poll(fn) {
  const end=performance.now()+10000
  while(performance.now()<end){const value=await fn();if(value)return value;await pause(12)}
  throw new Error('Observation timed out: '+String(fn).slice(0,120))
}
async function collect(app){
  const processes = await app.evaluate(({app,BrowserWindow})=>{
    const wins=BrowserWindow.getAllWindows()
    return app.getAppMetrics().map(m=>{
      const w=wins.find(w=>w.webContents.getOSProcessId()===m.pid)
      return {pid:m.pid,role:w?w.webContents.getURL().split('/').pop():m.type,visible:w?w.isVisible():null}
    })
  })
  for(const p of processes){
    const m=await fs.readFile('/proc/'+p.pid+'/smaps_rollup','utf8')
    p.pssKiB=Number(/^Pss:\s+(\d+)/m.exec(m)[1])
  }
  return processes
}
async function readReport(profile){
  try{return JSON.parse(await fs.readFile(path.join(profile,'help-latest.json'),'utf8'))}catch{return {}}
}
async function windowsCase(app,page,profile,mode){
  if(mode==='prepared')await poll(async()=>(await readReport(profile)).stages?.['first-paint-ready'])
  const command=(name,...args)=>page.evaluate(([n,...a])=>window.timelineWindow.command(n,...a),[name,...args])
  async function help(id){
    await command('help','home')
    const r=await poll(async()=>{
      const q=(await readReport(profile)).requests?.find(x=>x.id===id)
      return q?.readyMs && q.shownMs?q:null
    })
    return {kind:r.kind,shown:r.shownMs-r.clickedMs,ready:r.readyMs-r.clickedMs}
  }
  const first=await help(1)
  if(first.kind!==mode)throw Error('wrong opening kind '+JSON.stringify(first))
  const hw=app.windows().find(p=>p.url().endsWith('/help.html'))
  const hiddenAfter=[]
  const reopens=[]
  for(let id=2;id<=4;id++){
    await hw.evaluate(()=>window.planrailHelp.command('close'))
    reopens.push(await help(id))
  }
  await hw.evaluate(()=>window.planrailHelp.command('close'))
  await pause(200)
  hiddenAfter.push(await collect(app))
  for(let cycle=0;cycle<3;cycle++){
    await command('release-notes')
    const w=await poll(()=>app.windows().find(p=>p.url().endsWith('/release-notes.html')))
    await w.getByRole('heading',{name:'WorkRail 1.0.0',exact:true}).waitFor()
    await w.evaluate(()=>window.planrailReleaseNotes.command('close'))
    await pause(200)
    hiddenAfter.push(await collect(app))
  }
  await command('close')
  const tray=await poll(async()=>{
    const m=await collect(app);return m.some(p=>p.visible===true)?null:m
  })
  return {first,reopens,hiddenAfter,tray}
}
async function prewarmCase(app,profile){
  const before=await collect(app)
  if(before.some(p=>p.role==='help.html'))throw Error('missed prewarm boundary')
  await poll(async()=>(await readReport(profile)).stages?.['first-paint-ready'])
  await pause(250)
  const after=await collect(app)
  const report=await readReport(profile)
  if(report.requests.length||!after.some(p=>p.role==='help.html'&&!p.visible))throw Error('help was opened or unidentified')
  const help=app.windows().find(p=>p.url().endsWith('/help.html'))
  const cdp=await help.context().newCDPSession(help)
  try{
    await cdp.send('Performance.enable')
    const {metrics}=await cdp.send('Performance.getMetrics')
    const heap=metrics.find(m=>m.name==='JSHeapUsedSize')
    return {before,after,stages:report.stages,helpHeapBytes:heap.value}
  }finally{await cdp.detach()}
}
async function ipcCase(app,page,order,n){
  const output={}
  const one=async(method,count)=>page.evaluate(async({method,count,n})=>{
    const durations=[]
    for(let i=0;i<count;i++){
      const t=performance.now();const reply=await window.simpleTimeline[method]();durations.push(performance.now()-t)
      if(!reply.ok)throw Error('IPC read failed')
      if(method==='getSnapshot'&&reply.data?.schedules?.length!==n)throw Error('fixture count mismatch '+JSON.stringify(Object.keys(reply)))
      if(count>1)await new Promise(resolve=>setTimeout(resolve,Math.max(0,120-(performance.now()-t))))
    }
    return durations
  },{method,count,n})
  await one('getSnapshot',1);await pause(1800)
  for(const method of order){
    await app.evaluate(()=>{
      const now=()=>performance.now()
      let last=now()
      const gaps=[]
      const timer=setInterval(()=>{const t=now();gaps.push(t-last);last=t},5)
      globalThis.finishProbe=()=>{clearInterval(timer);gaps.push(now()-last);return gaps}
    })
    const durations=await one(method,20)
    const gaps=await app.evaluate(()=>globalThis.finishProbe())
    output[method]={durations,gaps}
  }
  return output
}
async function run(seed,i,mode){
  const profile=await fs.mkdtemp(path.join(os.tmpdir(),'simple-timeline-perf2-'))
  let app
  try{
    app=await _electron.launch({chromiumSandbox:true,executablePath:dep('electron'),args:[path.resolve('artifacts/test-app/main/index.cjs')],env:{...process.env,SIMPLE_TIMELINE_TEST_PROFILE:profile,SIMPLE_TIMELINE_TEST_SEED:seed}})
    const p=await app.firstWindow()
    await p.waitForFunction(()=>document.documentElement.dataset.timelinePhase==='ready')
    const data=mode==='prewarm'?await prewarmCase(app,profile):mode==='ipc'?await ipcCase(app,p,i%2?['getStatus','getSnapshot']:['getSnapshot','getStatus'],seed==='scale'?10000:3):await windowsCase(app,p,profile,mode)
    stats.push({seed,i,mode,data})
    await fs.writeFile(path.join(__dirname,mode==='prewarm'?'prewarm.json':'raw.json'),JSON.stringify(stats))
    console.log(seed,i,mode,'ok')
  }finally{if(app)await app.close();await fs.rm(profile,{recursive:true,force:true})}
}
;(async()=>{
 if(process.argv.includes('--prewarm')){for(let i=1;i<=5;i++)await run('hotfix',i,'prewarm');return}
 if(process.argv.includes('--resume-ipc')){
   const saved=JSON.parse(await fs.readFile(path.join(__dirname,'raw.json'),'utf8')).filter(x=>x.mode!=='ipc')
   if(saved.length!==10)throw Error('Expected 10 window observations')
   stats.push(...saved)
 } else for(let i=1;i<=5;i++)for(const mode of i%2?['cold','prepared']:['prepared','cold'])await run('hotfix',i,mode)
 for(let i=1;i<=3;i++)for(const seed of i%2?['hotfix','scale']:['scale','hotfix'])await run(seed,i,'ipc')
})().catch(e=>{console.error(e);process.exitCode=1})
