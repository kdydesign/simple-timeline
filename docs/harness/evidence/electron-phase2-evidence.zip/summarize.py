from pathlib import Path
import json, math
from statistics import median
base=Path(__file__).resolve().parent
rows=json.loads((base/'raw.json').read_text())
def span(values):
    return [round(f(values),1) for f in (min,median,max)]
def p95(a): return sorted(a)[math.floor(0.95*(len(a)-1))]
out={}
windows=[r for r in rows if r['mode']!='ipc']
for mode in ('cold','prepared'):
    subset=[r['data'] for r in windows if r['mode']==mode]
    out[mode]={k:span([d['first'][k] for d in subset]) for k in ('shown','ready')}
out['reopen']={k:span([median([v[k] for v in r['data']['reopens']]) for r in windows]) for k in ('shown','ready')}
def pss(s,role=None):return sum(p['pssKiB'] for p in s if role is None or p['role']==role)/1024
out['windows']={}
for k,extract in [('help_hidden',lambda d:d['hiddenAfter'][0]),('both_hidden',lambda d:d['hiddenAfter'][1]),('cycle3',lambda d:d['hiddenAfter'][3]),('tray',lambda d:d['tray'])]:
    snapshots=[extract(r['data']) for r in windows]
    out['windows'][k]={str(role):span([pss(s,role) for s in snapshots]) for role in (None,'index.html','help.html','release-notes.html')}
    out['windows'][k]['roles']=[(p['role'],p['visible']) for p in snapshots[0]]
out['paired_release_delta']=span([pss(r['data']['hiddenAfter'][1])-pss(r['data']['hiddenAfter'][0]) for r in windows])
out['renderer_pids_stable']=all(all(sorted(p['pid'] for p in s if p['role'].endswith('.html'))==sorted(p['pid'] for p in r['data']['hiddenAfter'][1] if p['role'].endswith('.html')) for s in r['data']['hiddenAfter'][2:]+[r['data']['tray']]) for r in windows)
out['tray_all_hidden']=all(not any(p['visible'] for p in r['data']['tray']) for r in windows)
out['ipc']={}
for seed in ('hotfix','scale'):
    group=[r['data'] for r in rows if r['mode']=='ipc' and r['seed']==seed]
    if group:
        out['ipc'][seed]={}
        for key in ('getStatus','getSnapshot'):
            out['ipc'][seed][key]={lab:span([fun(d[key][field]) for d in group]) for lab,fun,field in [('roundtrip_median',median,'durations'),('roundtrip_p95',p95,'durations'),('main_gap_p95',p95,'gaps'),('main_gap_max',max,'gaps'),('gaps_gt50',lambda g:sum(t>50 for t in g),'gaps')]}
if (base/'prewarm.json').exists():
    pre=[r['data'] for r in json.loads((base/'prewarm.json').read_text())]
    out['unused_help']={'help_pss_mib':span([pss(d['after'],'help.html') for d in pre]),'paired_app_delta_mib':span([pss(d['after'])-pss(d['before']) for d in pre]),'help_v8_heap_mib':span([d['helpHeapBytes']/1048576 for d in pre])}
(base/'summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
